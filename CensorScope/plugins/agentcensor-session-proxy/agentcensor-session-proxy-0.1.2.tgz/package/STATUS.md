# 状态与待办(agentcensor-session-proxy)

> 独立于 README 的开发状态记录,供后续会话/用户续接。最后更新:2026-09-10(协议级 cancel + 审批/提问交互桥落地)。

## 1. 最终交付物

```
README.md                                 唯一使用说明(安装/启动/行为/限制)
agentcensor-session-proxy/                插件源码
├── lib/index.mjs                          宿主侧:会话代理(WebDriverAgent;worker 路由 + 透明回放)
├── lib/worker.mjs                         worker 侧:常驻 runner(原生 agent-loop + 双向帧协议)
├── lib/interaction-bridge.mjs             宿主侧:审批/提问交互桥(控制面;只派发 waterfall,不写会话数据)
├── package.json / cordis.patch.yml        包元数据与 bundle patch(禁用 agent-loop + session-title-llm,插入本 bundle)
agentcensor-session-proxy-0.1.2.tgz        安装即用包(与源码一致)
```

安装/启动:

```sh
dsh plugin --profile web add /绝对路径/to/agentcensor-session-proxy-0.1.2.tgz
dsh web
```

约定:代码/配置零绝对路径;插件依赖本机 dsh 0.1.5-rc.2;真实模型 key 与原生 dsh 一致
(env `DEEPSEEK_API_KEY` 或 web Settings/Models 页写 `$DSH_HOME/.credentials.yaml`)。

## 2. 已完成(均已实测)

- **每 session 一个常驻 worker 进程**:首条消息懒 spawn(mode=create/resume、seed 拷贝、
  overlay 钉死私有可写根),后续消息查表直接转交同一进程(原生 followup),turn 结束不销毁;
  会话关闭/宿主退出才优雅停(`shutdown` 帧 / stdin EOF)。
- **双向行协议**:worker→host `ACEVT`(会话事件)/`ACREADY`/`ACIDLE`/`ACERR`;
  host→worker `{"type":"message",…}` / `{"type":"shutdown"}`。
- **共享宿主配置(零注入)**:worker `DSH_HOME`=宿主 home,`settings.yaml`/`.credentials.yaml`/
  机器级 `cordis.patch.yml`/env 分层直读,无 key/模型 env 注入(离线 spike + 真实 E2E 验证)。
- **宿主透明回放**:worker 为内容权威;宿主对其事件 1:1 append 回放,不合成用户可见回复;
  共享 JSONL 唯一写者仍是宿主 —— 依据 rc.1 事实:浏览器 live 流只认宿主 ctx
  `session/event`,而宿主任何 live append 都会被持久化协调器无条件落盘,故"宿主零写入"
  在 rc.1 不可行(不改 dsh 源码前提下),回退态成立。
- **无逐 turn 超时/进程级 turn 控制**;worker 异常按"已回放事件 + 下次消息懒重建 resume"处理;
  boot 以 `ACREADY` 握手(失败即报)。
- 命名统一为 `agentcensor`(无 `m1d`/`dsh-web-worker-bridge` 残留)。
- 已验证:离线冒烟(EOF/shutdown 干净退出、空闲驻留不退出);真实 LLM 闭环(改名前后各一次
  PASS:同会话两条消息 **spawn=1**、store/durable 有序无重复、`worker closed code=0`、stderr 空);
  tarball 安装(`file:` 复制进 profile)在全新 home 可装、`--dump-config` 行正确。

## 2.1 协议级 cancel(2026-09-10 新增,已实测)

- 宿主 `WebDriverAgent.cancel(cause, options)`:`state.stop('SIGTERM')` 已删除。worker 存活时把
  `{type:'cancel',cause,keepInbox}` 写进 worker stdin;worker 未就绪(消息还排在 spawn 后面)时把
  取消挂起,等该消息帧写完后立刻补发,保证「消息 + 该 turn 被取消」与原生一致,而不是丢消息。
  没有任何在跑/在排队的工作时取消是 no-op(不 arm 后续 turn,原生语义)。
- worker `controlLoop`:cancel 帧**不排队**进 message chain,读到即生效 —— `agent.status === 'running'`
  时直接 `agent.cancel(...)`;否则若已有排队消息则 latch,由那条消息的 `runOneTurn` 在 `followup()`
  之后立刻应用;两者都不是则 no-op。三种情况都回 `ACCANCEL` 帧({cause,keepInbox,seq,applied}).
- 结果事件完全由原生 agent-loop 产生(tool/result 收口、`step/end`、`turn/end {kind:'aborted',reason}`),
  照常 1:1 回放进宿主会话;worker 驻留、下一条消息同进程服务;turn 正常收口 ⇒ 下次 resume 不再补
  `interruptedTurnClosers`(+3)+`end-seed`(+1),宿主游标不会再被推到 `+4` 的死锁区。
- 实测(真实模型、脚本化 stdin,`node cancel-test/drive.mjs <session> create 2500`):
  - 流式中途取消:`ACCANCEL {applied:"now",seq:251}` → `assistant/message`(已产内容保留)、
    `step/end`、`turn/end {kind:'aborted',reason:{kind:'user'}}`、`ACIDLE`;同 worker 继续服务
    第二条消息并 `turn/end {kind:'completed'}`,事件 seq 连续无缺口。
  - 取消与消息同时到达(`cancelDelay=0`):`applied:"now"` → `turn/end {aborted,user}`,worker 存活。
  - 空闲时取消:`applied:"noop"`(正常工作完成后再取消,不改任何状态)。
  - 回归验证:取消后的日志以 `turn/end` 收口(348 行),再次 resume `firstSeq=348`(= 事件数 +1 的
    end-seed),即**不再产生 +4 偏移**;作为对照,未闭合 turn 的日志 resume 会得到 +4(461→465)。

## 2.2 审批 / 提问交互桥(2026-09-10 新增,已实测)

**两个独立原因(实测确认)**

1. 审批:worker 里 `approval` 服务是有的(base 组合,policy=`ask`),但 dsh 唯一的交互应答端是
   浏览器 —— 它注册在**宿主**的 remote waterfall 上(`packages/client/ui-approval/src/client/index.ts:90`
   `ctx.remote.$on('approval/request', …)`,由 `packages/api/remotes/src/remote-events.ts` 以
   `mode:'waterfall'` 转发,而 `api-remotes` 行只挂在 web-app bundle)。worker 里链上无人 →
   服务按文档 fail-closed 归一化成 `unavailable` → `escalation.ts:186` 抛
   "requires approval, but no approval channel is available"。
   实测日志(`session-8720b38b-…`):seq718 `approval/asked` → seq719 `approval/decided{outcome:"unavailable"}`
   (相隔 1ms,即"没有等待")→ seq720 工具报错。
2. 提问:worker 的 agent plane 来自 **base**(headless profile 不禁用 base 行、也不插 `agent-presets`),
   而 `tool-ask-user`(`ask_user_question`)只写在 web 面才挂载的 `standard` agent preset 里
   (`packages/preset/agent-presets/presets/standard/agent.cordis.yml:237`)。实测:worker 的
   `request/header` 只有 26 个工具且无 `ask_user_question`;overlay 补插该行后 27 个且有。
   即使工具存在,worker 里 `user-questions/request` 也无应答器(`NO_PROVIDER`)。

**实现**

- `lib/worker.mjs`:注册 `ctx.on('approval/request')` / `ctx.on('user-questions/request')` 应答器,
  经 `ACASK` 帧转发(剥掉不可序列化的 `agent`/`signal`),等宿主的 `answer` 帧;请求 signal 中止时
  发 `ACWITHDRAW` 并返回原生 `cancelled`/中止结果;宿主无答案 → `next()`,保持原生 fail-closed。
- `lib/index.mjs`:overlay `insert` 增补 `tool-ask-user`;消费 `ACASK`/`ACWITHDRAW`,交给
  `lib/interaction-bridge.mjs`;取消(停止)/worker 关闭时 withdraw 全部待答 ask。
- `lib/interaction-bridge.mjs`(**控制面,零会话写入**):用宿主 agent 作 subject 派发
  `ctx.waterfall(scopeTarget(agent, agent), 'approval/request' | 'user-questions/request', req, fallback)`
  —— 与原生服务同一条派发路径。**刻意不用** `ctx.approval.request()` / `ctx.userQuestions.ask()`:
  那会在同一会话追加**第二份**审计对,且审批服务要求自身 agent 会话处于 open turn。请求里带
  AbortSignal,gateway 把它绑到 pending remote event(`projected.signal` → cancel 帧),因此 withdraw
  会让浏览器弹窗消失;无客户端时 gateway 走 `next()`,桥据此回 `ok:false`,worker 走原生 fail-closed。
  可选 `AGENTCENSOR_ASK_TIMEOUT_MS`(默认 0=像原生一样一直等)。

**实测(真实模型 + 脚本化 stdin 假宿主,`interaction-test.mjs`)**

| 场景 | 结果 |
|---|---|
| 宿主回 `allowed-once` | `approval/decided{allowed-once}`;提权命令真的执行(不再是 "no approval channel") |
| 宿主回 `rejected` | `approval/decided{rejected}`;工具结果 = 原生 `the user rejected escalating this command to "danger-full-access"` |
| 宿主回 `ok:false`(模拟无浏览器) | `approval/decided{unavailable}` + 原生 "no approval channel is available" —— 与不装插件完全一致 |
| `ask_user_question` | worker 模型成功调用该工具;工具结果 = `{"answers":[{"id":"probe_question","selected":["选项 A(推荐)"]}]}` |
| 待答时按停止 | worker 发 `ACWITHDRAW`;`approval/decided{cancelled}`;工具结果 = 原生 `approval for escalating to "danger-full-access" was cancelled`;turn `aborted` |

另外 `bridge.test.mjs`(无需 dsh,24 项断言)覆盖宿主桥:派发事件名/subject scope carrier/字段透传、
`unavailable` 兜底、异常包含、提问答案、withdraw 中止 signal 且只回一帧、disposeAgent 批量 withdraw、
重复 id 拒绝。

**边界(与 A3/A4 的关系)**:桥只做交互请求与答案的中转,**不 append 任何会话事件**;审计对
`approval/asked`/`approval/decided`、`tool/result` 全部由 worker 的服务与 agent-loop 写,经 1:1 镜像
进宿主日志 —— "worker 是内容权威,宿主从不合成会话数据" 不变。

## 3. 剩余问题

### 3.1 功能缺口(原 Phase3 决策项,A/B/C 编号沿用决策记录)

| 编号 | 问题 | 现状 |
|---|---|---|
| B4 | 审批/提问桥:**已完成** —— worker 注册 `approval/request` + `user-questions/request` 应答器转 `ACASK`,宿主派发同一个 remote waterfall,浏览器弹窗作答回注;worker overlay 另补挂 `tool-ask-user` | 见 §2.2 |
| A2 | cancel 语义:**已完成** —— 停止按钮 = 协议级取消(宿主转发 `{"type":"cancel"}` 帧 → worker 内原生 `agent.cancel(cause,{keepInbox})` → 原生中止事件回放;worker 不杀、常驻保留) | 见 §2「协议级 cancel」;宿主侧 `cancel()` 不再 SIGTERM |
| A3 | 镜像非纯回放:仍有 seq 守卫/skip/宿主补插 end-seed/缺口拒绝 | 目标:append-only 1:1 全字段回放,一致性改为"启动前 fail-fast",宿主不发明事件 |
| A4 | boot 失败仍由宿主合成"worker unavailable"回合(仅在 worker 从未 ready 时) | 目标:失败以 worker 自身事件表达,宿主零合成(可保留非 durable 上报) |
| C7 | 事件序列化只取 {type,seq,data,surfaceOp,sourceEventSeqs} 五个字段 | 目标:session.append 全字段透传(dsh 更新加字段不丢) |
| C1 | 图片/附件:消息对象已全量转发,附件字节与宿主 attachment 库未对接 | 未实现(需撤私有 attachment 根重定向等) |
| C3 | `DSH_AGENTS_HOME` 仍覆盖为私有目录 → worker 看不到宿主 `~/.agents` 技能 | 未对齐(撤覆盖,与宿主同根,需评估并发) |
| C2 | worker overlay 仍禁用 `plugin-package-inventory-deepseek` → 请求载荷与宿主差一个扩展 | 待回归:恢复启用并验证 REQUEST_EXTENSION 是否复现 |
| C4 | spawn cwd/.env/沙箱根 vs 宿主启动目录:未核对工具实际取工作目录的来源 | 未对齐(需源码确认 session meta vs process.cwd) |

### 3.2 生命周期健壮性(原 N1-N5,未打磨)

- 会话删除时停止对应 worker、宿主硬退出的子进程清理:目前仅 dispose/进程 `exit` 钩子/
  stdin EOF 兜底,未系统化;
- worker 僵死(非崩溃)无心跳/监督,只能靠协议 cancel 或下次消息懒重建;
- worker 空闲期自主事件(goal/schedule/timer 触发)经长活 stdout 理论上实时可回灌,未单独验证;
- 多会话并发、取消、超长任务在"常驻"模型下未回归。

### 3.3 验证缺口

- 浏览器人工逐字上屏 / 多会话 UI 目视(长期遗留);
- 改名后的"双消息单进程"E2E 未重跑(代码等价,建议补一次);
- check-restart-flow 类"宿主重启后续聊"验收未在新代码上重跑。

## 4. 建议的下一步顺序

1. 回归:双消息单进程、取消、多会话、宿主重启(补足 3.3);
3. A3/A4/C7 纯回放改造(去守卫/去合成/全字段透传,启动前 fail-fast);
4. B4 审批/提问桥;
5. 其余小项:C3/C2/C1/C4 对齐;生命周期 N1-N5 打磨。
